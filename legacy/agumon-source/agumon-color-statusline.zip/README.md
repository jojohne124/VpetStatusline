﻿# Agumon Color Statusline for Claude Code

Claude Code 的 statusline 會顯示彩色亞古獸走路動畫。

## 先決條件
- Node.js 18+
- Claude Code CLI

## 安裝（Windows）
```powershell
cd <此資料夾路徑>
.\install.ps1
```
安裝後 30 秒內 statusline 自動出現，不需重啟 Claude Code。

## 亞古獸行為
| 行為 | 觸發條件 |
|---|---|
| 走路 | 平時左右來回 |
| 大吼 | 送出訊息時 |
| 表情（開心/驚訝/怒視等）| 隨機觸發 |
| 睡覺（呼吸動畫）| 2 分鐘沒有送訊息 |

## 解除安裝
編輯 `C:\Users\<你>\.claude\settings.json`，
將 `statusLine.command` 改回原本設定或刪除整個 `statusLine` 欄位。
